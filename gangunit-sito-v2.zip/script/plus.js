/* ════════════════════════════════════════════════════════════════
   GANG UNIT · NOW V4 — PLUS (grafica e animazioni in più)
   Si carica DOPO script/sito.js. Non cambia il funzionamento del sito:
   aggiunge effetti, la barra degli avvisi, transizioni tra le sezioni
   e i nuovi strumenti operativi.
   ════════════════════════════════════════════════════════════════ */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const RIDOTTO = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const TOCCO = matchMedia('(hover: none)').matches;
  document.documentElement.classList.add('plus');

  /* ── sfondo animato ── */
  const aurora = document.createElement('div'); aurora.id = 'sp-aurora'; aurora.setAttribute('aria-hidden', 'true');
  aurora.innerHTML = '<i class="a1"></i><i class="a2"></i><i class="a3"></i><b></b>';
  document.body.prepend(aurora);

  /* ── barra in alto che si compatta scorrendo ── */
  const barra = $('#barra');
  const scorri = () => barra?.classList.toggle('sp-scorre', scrollY > 12);
  addEventListener('scroll', scorri, { passive: true }); scorri();

  /* ── transizione quando cambia sezione ── */
  const viste = $$('.vista');
  const mo = new MutationObserver(ms => ms.forEach(m => { const v = m.target; if (!v.hidden && !RIDOTTO) { v.classList.remove('sp-entra'); void v.offsetWidth; v.classList.add('sp-entra'); } }));
  viste.forEach(v => mo.observe(v, { attributes: true, attributeFilter: ['hidden'] }));

  /* ── HERO: tutta la larghezza, faro dell'elicottero e parallasse ── */
  const hero = $('.hero');
  if (hero) {
    const bg = $('.hero-bg', hero);
    if (bg) { const sfoca = document.createElement('div'); sfoca.className = 'sp-hero-fondo'; sfoca.style.backgroundImage = `url("${bg.getAttribute('src')}")`; hero.prepend(sfoca); }
    hero.insertAdjacentHTML('beforeend', '<div class="sp-faro" aria-hidden="true"></div><div class="sp-hero-luce" aria-hidden="true"></div>');
    if (!RIDOTTO && !TOCCO) {
      hero.addEventListener('pointermove', e => { const r = hero.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; hero.style.setProperty('--px', `${x * -18}px`); hero.style.setProperty('--py', `${y * -12}px`); hero.style.setProperty('--lx', `${(x + .5) * 100}%`); hero.style.setProperty('--ly', `${(y + .5) * 100}%`); });
      hero.addEventListener('pointerleave', () => { hero.style.setProperty('--px', '0px'); hero.style.setProperty('--py', '0px'); });
    }
  }

  /* ── HOME: striscia degli avvisi sotto il banner ── */
  if (hero) {
    const avvisi = ['<b>GU-NOW-001</b> · Rev. 1.0 in vigore', 'Livello di minaccia <em class="sp-liv">VERDE</em>', '<b>10-99</b> agente in pericolo · tutte le unità', '<b>G-3</b> scontro tra gang · non entrare da soli', 'Raid solo con autorizzazione del <b>Capitano</b>', 'Timbra sempre entrata e uscita', 'Nessun contatto non operativo con le gang', 'La vita dell\'ostaggio viene prima di tutto'];
    const nastro = document.createElement('div'); nastro.className = 'sp-nastro'; nastro.setAttribute('aria-hidden', 'true');
    nastro.innerHTML = `<div class="sp-nastro-l"><i></i>LIVE</div><div class="sp-nastro-scorre"><div>${[...avvisi, ...avvisi].map(a => `<span>◆ ${a}</span>`).join('')}</div></div><div class="sp-nastro-ora" id="sp-nastro-ora">--:--</div>`;
    hero.after(nastro);
    const liv = () => { const l = (document.body.dataset.minaccia || 'verde'); $$('.sp-liv', nastro).forEach(x => { x.textContent = l.toUpperCase(); }); nastro.dataset.min = l; };
    liv(); new MutationObserver(liv).observe(document.body, { attributes: true, attributeFilter: ['data-minaccia'] });
    const ora = () => { $('#sp-nastro-ora').textContent = new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Rome' }); };
    ora(); setInterval(ora, 15000);
  }

  /* ── HOME: icone nei riquadri dei numeri ── */
  const ICO_N = [
    '<path d="m12 3 2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.4l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/>',
    '<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>',
    '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 19.5V4.5M8 7h8M8 11h6"/>',
    '<rect x="6" y="8" width="12" height="14" rx="2"/><path d="M9 8V2M10 13h4M10 17h4"/>',
    '<path d="M12 3 2 8l10 5 10-5z"/><path d="M6 10.5V16c3 2.5 9 2.5 12 0v-5.5"/>',
  ];
  const COL_N = ['#f5b942', '#a78bfa', '#3b82f6', '#2fd38a', '#ff9f43'];
  $$('.numeri > div').forEach((d, i) => { d.style.setProperty('--nc', COL_N[i % 5]); d.insertAdjacentHTML('afterbegin', `<span class="sp-n-ico" aria-hidden="true"><svg viewBox="0 0 24 24">${ICO_N[i % 5]}</svg></span>`); });

  /* ── luce che segue il mouse sulle card ── */
  if (!TOCCO) {
    const SEL = '.cat, .cap-a, .numeri > div, .bando-card, .es-card, .finale-card, .pron, .riquadro, .percorso li, .alto-comando, .scheda, .candidato, .art';
    document.addEventListener('pointermove', e => {
      const c = e.target.closest?.(SEL); if (!c) return;
      if (!c.querySelector(':scope > .sp-luce')) { const l = document.createElement('span'); l.className = 'sp-luce'; l.setAttribute('aria-hidden', 'true'); c.appendChild(l); if (getComputedStyle(c).position === 'static') c.style.position = 'relative'; }
      const r = c.getBoundingClientRect(); c.style.setProperty('--mx', `${e.clientX - r.left}px`); c.style.setProperty('--my', `${e.clientY - r.top}px`);
    }, { passive: true });
  }

  /* ── card con leggera inclinazione 3D ── */
  if (!RIDOTTO && !TOCCO) {
    let att = null;
    document.addEventListener('pointermove', e => {
      const c = e.target.closest?.('.cat, .cap-a, .es-card'); if (att && att !== c) { att.style.transform = ''; att = null; }
      if (!c) return; att = c; const r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
      c.style.transform = `perspective(900px) rotateX(${y * -5}deg) rotateY(${x * 6}deg) translateY(-3px)`;
    }, { passive: true });
    document.addEventListener('pointerleave', () => { if (att) att.style.transform = ''; }, true);
  }

  /* ── pulsanti principali: riflesso al passaggio ── */
  document.addEventListener('pointerover', e => { const b = e.target.closest?.('.btn.p'); if (b && !b.dataset.sp) { b.dataset.sp = 1; b.insertAdjacentHTML('beforeend', '<span class="sp-lampo" aria-hidden="true"></span>'); } });
})();
/* ════════════════════════════════════════════════════════════════
   GANG UNIT · NOW V4 — STRUMENTI PLUS
   Si aggiunge DOPO script/sito.js: non cambia niente di quello che c'è,
   aggiunge console, radio, sfida a tempo, modalità campo, anteprima
   Discord, calcolatore di carriera e ricerca nelle domande frequenti.
   ════════════════════════════════════════════════════════════════ */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const vista = $('#v-strumenti'); if (!vista) return;
  const RIDOTTO = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const LS = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* niente */ } } };
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const mescola = a => { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; };
  const avviso = (t) => { let el = $('#sp-toast'); if (!el) { el = document.createElement('div'); el.id = 'sp-toast'; el.setAttribute('role', 'status'); document.body.appendChild(el); } el.textContent = t; el.classList.add('on'); clearTimeout(avviso.t); avviso.t = setTimeout(() => el.classList.remove('on'), 2200); };

  /* ── suoni radio (WebAudio, partono solo dopo un clic) ── */
  let ac; const audio = () => { try { ac ||= new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === 'suspended') ac.resume(); return ac; } catch { return null; } };
  let muto = LS.get('gu-sp-muto', false);
  function bip(f = 1150, d = .09, v = .07, quando = 0) { const a = !muto && audio(); if (!a) return; const o = a.createOscillator(), g = a.createGain(), t = a.currentTime + quando; o.type = 'square'; o.frequency.value = f; g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(.0001, t + d); o.connect(g).connect(a.destination); o.start(t); o.stop(t + d + .02); }
  function fruscio(d = .28, v = .05) { const a = !muto && audio(); if (!a) return; const n = a.sampleRate * d, b = a.createBuffer(1, n, a.sampleRate), x = b.getChannelData(0); for (let i = 0; i < n; i++) x[i] = (Math.random() * 2 - 1) * (1 - i / n); const s = a.createBufferSource(), f = a.createBiquadFilter(), g = a.createGain(); f.type = 'bandpass'; f.frequency.value = 1800; f.Q.value = .8; g.gain.value = v; s.buffer = b; s.connect(f).connect(g).connect(a.destination); s.start(); }
  const trasmetti = () => { fruscio(); bip(1400, .07, .06, .05); bip(1000, .1, .06, .16); };

  /* ── dati presi dalla pagina (così restano sempre allineati al regolamento) ── */
  const codici = () => $$('#s-radio .tab tbody tr').map(tr => { const td = tr.children; return { c: td[0]?.textContent.trim(), s: td[1]?.textContent.trim(), t: (td[2]?.querySelector('.pill')?.className || '').replace('pill', '').trim(), tl: td[2]?.textContent.trim() }; }).filter(x => x.c);
  const ICONE = {
    radio: '<svg viewBox="0 0 24 24"><rect x="6" y="8" width="12" height="14" rx="2"/><path d="M9 8V2M10 13h4M10 17h4"/></svg>',
    prontuario: '<svg viewBox="0 0 24 24"><path d="M9 4h6v3H9zM7 5H5v17h14V5h-2"/><path d="m8.5 13 2.2 2.2L15.5 10.5"/></svg>',
    moduli: '<svg viewBox="0 0 24 24"><path d="M14 2H6v20h12V6z"/><path d="M14 2v4h4M9 12h6M9 16h6"/></svg>',
    carriera: '<svg viewBox="0 0 24 24"><path d="M4 20h4v-6H4zM10 20h4V9h-4zM16 20h4V4h-4z"/></svg>',
    faq: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5"/><path d="M9.5 9.2a2.6 2.6 0 0 1 5 .8c0 1.8-2.5 2.2-2.5 4M12 17.5v.01"/></svg>',
  };
  const DESCR = { radio: 'Codici, radio e sfide', prontuario: 'Checklist sul campo', moduli: 'Rapporti per Discord', carriera: 'Gradi e promozioni', faq: 'Risposte rapide' };
  const COLORI = { radio: '#7cb0ff', prontuario: '#ff4d5e', moduli: '#2fd38a', carriera: '#a78bfa', faq: '#22d3ee' };

  /* ═════════════ 1 · CONSOLE IN TESTA ═════════════ */
  const testa = $('.pagina-testa', vista);
  if (testa) {
    testa.classList.add('sp-console');
    testa.insertAdjacentHTML('beforeend', `
      <div class="sp-radar" aria-hidden="true"><canvas id="sp-radar" width="300" height="300"></canvas><span class="sp-radar-l">SCAN · LOS SANTOS</span></div>
      <div class="sp-stato">
        <div class="sp-orologio"><b id="sp-ora">--:--:--</b><span id="sp-data"></span></div>
        <div class="sp-min"><i></i><span>Minaccia</span><b id="sp-min">—</b></div>
        <div class="sp-cifre"><span><b id="sp-n-cod">0</b>codici</span><span><b id="sp-n-pro">0</b>procedure</span><span><b id="sp-n-mod">0</b>moduli</span></div>
      </div>`);
    const ora = () => { const d = new Date(); $('#sp-ora').textContent = d.toLocaleTimeString('it-IT', { timeZone: 'Europe/Rome' }); $('#sp-data').textContent = d.toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'Europe/Rome' }); };
    ora(); setInterval(ora, 1000);
    const min = () => { const l = document.body.dataset.minaccia || 'verde'; $('#sp-min').textContent = l.toUpperCase(); testa.dataset.min = l; };
    min(); new MutationObserver(min).observe(document.body, { attributes: true, attributeFilter: ['data-minaccia'] });
    const cifre = () => { $('#sp-n-cod').textContent = codici().length; $('#sp-n-pro').textContent = $$('#prontuario .pron').length; $('#sp-n-mod').textContent = $$('#moduli-sel button').length; };
    cifre(); setTimeout(cifre, 800);
    // radar
    const cv = $('#sp-radar'), x = cv.getContext('2d'); const W = 300, C = W / 2;
    const punti = Array.from({ length: 9 }, () => ({ a: Math.random() * 6.28, r: 30 + Math.random() * 110, v: 0 }));
    let ang = 0, t0 = performance.now();
    (function giro(t) {
      requestAnimationFrame(giro);
      if (vista.hidden || document.hidden) return;
      const dt = Math.min(50, t - t0); t0 = t; ang = (ang + (RIDOTTO ? 0 : dt * .0016)) % (Math.PI * 2);
      x.clearRect(0, 0, W, W);
      x.strokeStyle = 'rgba(124,176,255,.18)'; x.lineWidth = 1;
      for (const r of [40, 80, 120, 146]) { x.beginPath(); x.arc(C, C, r, 0, 7); x.stroke(); }
      x.beginPath(); x.moveTo(C, 4); x.lineTo(C, W - 4); x.moveTo(4, C); x.lineTo(W - 4, C); x.stroke();
      const g = x.createConicGradient ? x.createConicGradient(ang - .9, C, C) : null;
      if (g) { g.addColorStop(0, 'rgba(59,130,246,0)'); g.addColorStop(.14, 'rgba(59,130,246,.35)'); g.addColorStop(.145, 'rgba(59,130,246,0)'); x.fillStyle = g; x.beginPath(); x.arc(C, C, 146, 0, 7); x.fill(); }
      x.strokeStyle = 'rgba(124,176,255,.9)'; x.lineWidth = 2; x.beginPath(); x.moveTo(C, C); x.lineTo(C + Math.cos(ang) * 146, C + Math.sin(ang) * 146); x.stroke();
      const col = getComputedStyle(testa).getPropertyValue('--sp-min-c').trim() || '#2fd38a';
      for (const p of punti) {
        const d = ((ang - p.a) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2); if (d < .05) p.v = 1; p.v *= .985;
        if (p.v > .02) { x.fillStyle = col; x.globalAlpha = p.v; x.beginPath(); x.arc(C + Math.cos(p.a) * p.r, C + Math.sin(p.a) * p.r, 4, 0, 7); x.fill(); x.globalAlpha = p.v * .35; x.beginPath(); x.arc(C + Math.cos(p.a) * p.r, C + Math.sin(p.a) * p.r, 11, 0, 7); x.fill(); x.globalAlpha = 1; }
      }
    })(t0);
  }

  /* ═════════════ 2 · SCHEDE GRANDI CON ICONA ═════════════ */
  const schede = $('.schede', vista);
  if (schede) {
    schede.classList.add('sp-schede');
    $$('[data-s]', schede).forEach((b, i) => {
      const k = b.dataset.s; b.style.setProperty('--c', COLORI[k] || '#7cb0ff');
      b.innerHTML = `<span class="sp-ico">${ICONE[k] || ''}</span><span class="sp-tt"><b>${esc(b.textContent)}</b><small>${DESCR[k] || ''}</small></span><kbd>${i + 1}</kbd>`;
    });
    document.addEventListener('keydown', e => {
      if (vista.hidden || e.ctrlKey || e.metaKey || e.altKey || e.target.closest('input,textarea,select,[contenteditable="true"]')) return;
      const b = $$('[data-s]', schede)[+e.key - 1]; if (b) { location.hash = 'strumenti-' + b.dataset.s; }
    });
  }

  /* ═════════════ 3 · RADIO DI SERVIZIO ═════════════ */
  const sRadio = $('#s-radio');
  if (sRadio) {
    sRadio.insertAdjacentHTML('afterbegin', `
    <div class="sp-radio riquadro">
      <div class="sp-r-corpo">
        <div class="sp-r-antenna" aria-hidden="true"></div>
        <div class="sp-lcd" aria-live="polite">
          <div class="sp-lcd-top"><span>GU · CH <b id="sp-ch">1</b></span><span id="sp-freq">154.280 MHz</span><span class="sp-seg" aria-hidden="true"><i></i><i></i><i></i><i></i></span></div>
          <div class="sp-lcd-cod" id="sp-lcd-cod">10-__</div>
          <div class="sp-lcd-sig" id="sp-lcd-sig">Digita un codice o tocca un tasto rapido</div>
        </div>
        <div class="sp-tast" role="group" aria-label="Tastierino della radio">
          ${['1', '2', '3', '4', '5', '6', '7', '8', '9', 'G', '0', '⌫'].map(k => `<button type="button" data-k="${k}">${k}</button>`).join('')}
        </div>
        <div class="sp-r-piede">
          <button type="button" class="sp-ptt" id="sp-ptt"><span>PTT</span>Trasmetti</button>
          <button type="button" class="sp-ch" id="sp-ch-btn" title="Cambia canale">CH ⟳</button>
          <button type="button" class="sp-muto" id="sp-muto" aria-pressed="${muto}" title="Suoni on/off">${muto ? '🔇' : '🔊'}</button>
        </div>
      </div>
      <div class="sp-r-lato">
        <h3 class="r-tit">Radio di servizio <small>Digita sul tastierino o usa i tasti rapidi: vedi il significato e senti il bip in trasmissione</small></h3>
        <div class="sp-rapidi" id="sp-rapidi"></div>
        <div class="sp-log" id="sp-log" aria-label="Ultime trasmissioni"><small>Ultime trasmissioni</small><ol></ol></div>
      </div>
    </div>`);
    const CANALI = [['1', '154.280 MHz'], ['2', '154.415 MHz'], ['3', '155.730 MHz'], ['T', '460.025 MHz · TAC']];
    let ch = 0, buf = '', cifre = '';
    const trova = (c) => codici().find(x => x.c.toUpperCase() === c.toUpperCase());
    function mostra(c, invia = false) {
      const x = trova(c);
      $('#sp-lcd-cod').textContent = c || '10-__';
      $('#sp-lcd-sig').textContent = x ? x.s : c ? 'Codice non in elenco' : 'Digita un codice o tocca un tasto rapido';
      sRadio.querySelector('.sp-lcd').dataset.t = x?.t || '';
      if (invia && x) {
        trasmetti();
        const li = document.createElement('li'); li.innerHTML = `<time>${new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</time><b>${esc(x.c)}</b><span>${esc(x.s)}</span>`;
        const ol = $('#sp-log ol'); ol.prepend(li); while (ol.children.length > 6) ol.lastChild.remove();
        sRadio.querySelector('.sp-radio').classList.remove('tx'); void sRadio.offsetWidth; sRadio.querySelector('.sp-radio').classList.add('tx');
      }
    }
    function digita(k) {
      bip(1700, .035, .04);
      if (k === '⌫') buf = buf.slice(0, -1);
      else if (k === 'G') buf = 'G-';
      else if (buf.startsWith('G-')) buf = (buf + k).slice(0, 3);
      else buf = (cifre + k).slice(0, 4);
      if (k === '⌫' && !buf.startsWith('G-')) buf = cifre.slice(0, -1);
      if (!buf.startsWith('G-')) {
        cifre = buf.replace(/\D/g, '');
        // "1" e "10" sono a metà; "1071" o "71" diventano 10-71
        buf = !cifre ? '' : '10'.startsWith(cifre) ? cifre : cifre.startsWith('10') ? '10-' + cifre.slice(2, 4) : '10-' + cifre.slice(0, 2);
      } else cifre = '';
      mostra(buf);
    }
    $('.sp-tast', sRadio).addEventListener('click', e => { const b = e.target.closest('[data-k]'); if (b) digita(b.dataset.k); });
    $('#sp-ptt').addEventListener('click', () => { if (buf) mostra(buf, true); else avviso('Prima digita un codice'); });
    $('#sp-ch-btn').addEventListener('click', () => { ch = (ch + 1) % CANALI.length; $('#sp-ch').textContent = CANALI[ch][0]; $('#sp-freq').textContent = CANALI[ch][1]; fruscio(.18, .04); });
    $('#sp-muto').addEventListener('click', e => { muto = !muto; LS.set('gu-sp-muto', muto); e.currentTarget.textContent = muto ? '🔇' : '🔊'; e.currentTarget.setAttribute('aria-pressed', muto); });
    const RAPIDI = ['10-4', '10-20', '10-23', '10-32', '10-71', '10-80', '10-99', 'G-3', 'G-5'];
    const rapidi = () => { $('#sp-rapidi').innerHTML = RAPIDI.map(c => trova(c)).filter(Boolean).map(x => `<button type="button" data-rc="${esc(x.c)}" class="sp-rc ${esc(x.t)}"><b>${esc(x.c)}</b><span>${esc(x.s)}</span></button>`).join(''); };
    rapidi(); setTimeout(rapidi, 600);
    $('#sp-rapidi').addEventListener('click', e => { const b = e.target.closest('[data-rc]'); if (b) { buf = b.dataset.rc; cifre = buf.startsWith('G') ? '' : buf.replace(/\D/g, ''); mostra(buf, true); } });
    document.addEventListener('keydown', e => {
      if (sRadio.hidden || vista.hidden || e.target.closest('input,textarea,select,[contenteditable="true"]')) return;
      if (e.key === 'Enter' && buf) { e.preventDefault(); mostra(buf, true); }
    });

    /* ── SFIDA A TEMPO ── */
    sRadio.insertAdjacentHTML('beforeend', `
    <div class="sp-sfida riquadro" id="sp-sfida">
      <div class="sp-sf-testa"><h3 class="r-tit">Sfida a tempo <small>60 secondi: scegli il significato giusto. Ogni risposta esatta di fila vale di più.</small></h3>
        <div class="sp-sf-rec">Record <b id="sp-rec">${LS.get('gu-sp-record', 0)}</b></div></div>
      <div class="sp-sf-gioco" id="sp-sf-gioco">
        <div class="sp-sf-start"><div class="sp-sf-big">⏱</div><p>Pronto a metterti alla prova sui codici radio?</p><button type="button" class="btn p" id="sp-sf-via">Inizia la sfida</button></div>
      </div>
    </div>`);
    let tempo = 0, punti = 0, serie = 0, timer = null, giuste = 0, totali = 0;
    function domanda() {
      const tutti = codici(); if (tutti.length < 4) return;
      const [g, ...altri] = mescola(tutti); const opz = mescola([g, ...mescola(altri.filter(x => x.s !== g.s)).slice(0, 3)]);
      $('#sp-sf-gioco').innerHTML = `
        <div class="sp-sf-hud"><span class="sp-sf-t"><i style="--p:${tempo / 60}"></i><b id="sp-sf-sec">${tempo}</b>s</span><span>Punti <b>${punti}</b></span><span>Serie <b>×${Math.min(5, 1 + Math.floor(serie / 3))}</b></span></div>
        <div class="sp-sf-cod">${esc(g.c)}</div>
        <div class="sp-sf-opz">${opz.map(o => `<button type="button" data-ok="${o === g ? 1 : 0}">${esc(o.s)}</button>`).join('')}</div>`;
    }
    function fine() {
      clearInterval(timer); timer = null;
      const rec = LS.get('gu-sp-record', 0), nuovo = punti > rec; if (nuovo) LS.set('gu-sp-record', punti); $('#sp-rec').textContent = Math.max(rec, punti);
      const voto = punti >= 150 ? ['Operatore radio d\'élite', 'var(--oro)'] : punti >= 80 ? ['Pronto per la centrale', 'var(--verde)'] : punti >= 30 ? ['Buona base, continua così', 'var(--blu-chiaro)'] : ['Ripassa i codici', 'var(--rosso)'];
      $('#sp-sf-gioco').innerHTML = `<div class="sp-sf-fine" style="--c:${voto[1]}"><div class="sp-sf-big">${punti}</div><b>${voto[0]}</b><p>${giuste} giuste su ${totali}${nuovo ? ' · <strong>nuovo record!</strong>' : ''}</p><button type="button" class="btn p" id="sp-sf-via">Rigioca</button></div>`;
      if (nuovo) { bip(880, .12, .06); bip(1320, .18, .06, .13); }
    }
    $('#sp-sfida').addEventListener('click', e => {
      if (e.target.closest('#sp-sf-via')) { tempo = 60; punti = 0; serie = 0; giuste = 0; totali = 0; domanda(); clearInterval(timer); timer = setInterval(() => { tempo--; const s = $('#sp-sf-sec'); if (s) { s.textContent = tempo; s.parentElement.querySelector('i').style.setProperty('--p', tempo / 60); } if (tempo <= 0) fine(); }, 1000); return; }
      const b = e.target.closest('.sp-sf-opz button'); if (!b || !timer || b.disabled) return;
      totali++;
      const ok = b.dataset.ok === '1';
      $$('.sp-sf-opz button', $('#sp-sfida')).forEach(x => { x.disabled = true; if (x.dataset.ok === '1') x.classList.add('ok'); });
      if (ok) { giuste++; serie++; punti += 10 * Math.min(5, 1 + Math.floor((serie - 1) / 3)); bip(1320, .07, .05); } else { serie = 0; b.classList.add('ko'); bip(220, .2, .06); }
      setTimeout(() => { if (timer) domanda(); }, ok ? 380 : 900);
    });
  }

  /* ═════════════ 4 · PRONTUARIO: ANELLI E MODALITÀ CAMPO ═════════════ */
  const pron = $('#prontuario');
  if (pron) {
    const avanzamento = (c) => { const tot = $$('input', c).length, n = $$('input:checked', c).length; c.style.setProperty('--pp', tot ? n / tot : 0); };
    const prepara = () => $$('.pron', pron).forEach(c => {
      if (c.dataset.sp) return; c.dataset.sp = 1; avanzamento(c);
      $('.pron-t', c).insertAdjacentHTML('afterbegin', '<span class="sp-anello" aria-hidden="true"></span>');
      $('.pron-p', c).insertAdjacentHTML('beforeend', '<button type="button" class="sp-campo-btn">▶ Modalità campo</button>');
    });
    prepara();
    pron.addEventListener('change', e => { const c = e.target.closest('.pron'); if (c) avanzamento(c); });
    pron.addEventListener('click', e => { const c = e.target.closest('.pron'); if (e.target.closest('.azzera') && c) setTimeout(() => avanzamento(c)); if (e.target.closest('.sp-campo-btn') && c) campo(c); });

    // overlay a schermo intero, un passo alla volta
    const ov = document.createElement('div'); ov.className = 'sp-campo'; ov.hidden = true; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-modal', 'true'); document.body.appendChild(ov);
    let card = null, i = 0;
    function disegna() {
      const passi = $$('li', card), tot = passi.length, cb = $$('input', card);
      const fatti = cb.filter(x => x.checked).length;
      ov.style.setProperty('--c', card.style.getPropertyValue('--c') || 'var(--blu)');
      ov.innerHTML = `
        <div class="sp-cp-testa"><div><small>Modalità campo</small><h2>${esc($('h3', card).textContent)}</h2></div><button type="button" class="sp-cp-x" aria-label="Chiudi">✕</button></div>
        <div class="sp-cp-barra"><i style="width:${fatti / tot * 100}%"></i></div>
        <div class="sp-cp-passi">${passi.map((_, k) => `<button type="button" data-v="${k}" class="${k === i ? 'qui' : ''} ${cb[k].checked ? 'ok' : ''}" aria-label="Passo ${k + 1}">${cb[k].checked ? '✓' : k + 1}</button>`).join('')}</div>
        <div class="sp-cp-passo ${cb[i].checked ? 'fatto' : ''}"><span class="sp-cp-n">Passo ${i + 1} di ${tot}</span><p>${esc(passi[i].textContent.trim())}</p></div>
        <div class="sp-cp-az">
          <button type="button" class="btn" data-a="indietro" ${i === 0 ? 'disabled' : ''}>← Indietro</button>
          <button type="button" class="btn p sp-cp-fatto" data-a="fatto">${cb[i].checked ? '↺ Segna da fare' : '✓ Fatto'}</button>
          <button type="button" class="btn" data-a="avanti" ${i === tot - 1 ? 'disabled' : ''}>Avanti →</button>
        </div>
        ${fatti === tot ? '<div class="sp-cp-ok">✓ Procedura completata</div>' : ''}
        <p class="sp-cp-aiuto">Tasti: <kbd>←</kbd> <kbd>→</kbd> per spostarti · <kbd>Spazio</kbd> per segnare · <kbd>Esc</kbd> per chiudere</p>`;
    }
    function campo(c) { card = c; const cb = $$('input', c); i = Math.max(0, cb.findIndex(x => !x.checked)); if (i < 0) i = 0; ov.hidden = false; document.documentElement.classList.add('sp-bloccato'); disegna(); $('.sp-cp-fatto', ov)?.focus(); }
    const chiudi = () => { ov.hidden = true; document.documentElement.classList.remove('sp-bloccato'); card?.querySelector('.sp-campo-btn')?.focus(); };
    function segna() { const cb = $$('input', card)[i]; cb.checked = !cb.checked; cb.dispatchEvent(new Event('change', { bubbles: true })); bip(cb.checked ? 1320 : 700, .06, .05); if (cb.checked && i < $$('li', card).length - 1) i++; disegna(); }
    ov.addEventListener('click', e => {
      if (e.target.closest('.sp-cp-x')) return chiudi();
      const v = e.target.closest('[data-v]'); if (v) { i = +v.dataset.v; return disegna(); }
      const a = e.target.closest('[data-a]')?.dataset.a; if (!a) return;
      if (a === 'fatto') segna(); else if (a === 'avanti') { i++; disegna(); } else if (a === 'indietro') { i--; disegna(); }
    });
    document.addEventListener('keydown', e => {
      if (ov.hidden) return;
      const tot = $$('li', card).length;
      if (e.key === 'Escape') chiudi();
      else if (e.key === 'ArrowRight' && i < tot - 1) { i++; disegna(); }
      else if (e.key === 'ArrowLeft' && i > 0) { i--; disegna(); }
      else if (e.key === ' ' && !e.target.closest('button')) { e.preventDefault(); segna(); }
    });
  }

  /* ═════════════ 5 · MODULI: ANTEPRIMA COME SU DISCORD ═════════════ */
  const area = $('#moduli-area');
  if (area) {
    const md = s => esc(s).replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/\n/g, '<br>');
    function discord() {
      const pre = $('#mod-pre'), box = $('.mod-anteprima', area); if (!pre || !box) return;
      let dc = $('.sp-dc', box);
      if (!dc) {
        box.insertAdjacentHTML('afterbegin', `<div class="sp-dc"><div class="sp-dc-testa"><span>#rapporti</span><small>Come apparirà su Discord</small></div><div class="sp-dc-msg"><img src="immagini/distintivo.jpg" alt=""><div><div class="sp-dc-nome"><b>Gang Unit Now V4</b><span class="sp-dc-app">APP</span><time></time></div><div class="sp-dc-testo"></div></div></div><div class="sp-dc-conta"><span></span><i><em></em></i></div></div>`);
        dc = $('.sp-dc', box);
      }
      const t = pre.dataset.discord || pre.textContent;
      $('.sp-dc-testo', dc).innerHTML = md(t);
      $('time', dc).textContent = 'Oggi alle ' + new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });
      const n = t.length, perc = Math.min(1, n / 2000);
      $('.sp-dc-conta span', dc).textContent = `${n} / 2000 caratteri${n > 2000 ? ' · troppo lungo per un messaggio' : ''}`;
      $('.sp-dc-conta em', dc).style.width = perc * 100 + '%'; dc.classList.toggle('lungo', n > 2000);
      // campi compilati
      const form = $('#mod-form'); if (form) { const c = $$('[data-c]', form), f = c.filter(x => x.value.trim()).length; let bar = $('.sp-compilato', form); if (!bar) { $('.r-tit', form).insertAdjacentHTML('afterend', '<div class="sp-compilato"><span></span><i><em></em></i></div>'); bar = $('.sp-compilato', form); } $('span', bar).textContent = `${f} di ${c.length} campi compilati`; $('em', bar).style.width = (c.length ? f / c.length * 100 : 0) + '%'; }
    }
    const mo = new MutationObserver(() => { mo.disconnect(); discord(); osserva(); });
    const osserva = () => { mo.observe(area, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['data-discord'] }); };
    discord(); osserva();
  }

  /* ═════════════ 6 · CARRIERA: IL MIO PERCORSO ═════════════ */
  const car = $('#carriera');
  if (car) {
    const REQ = { 'Recluta': { sett: 1, ore: 0, extra: 'Esame d\'accademia + 3 valutazioni positive' }, 'Agente I': { sett: 2, ore: 15, extra: 'Nessun richiamo attivo' }, 'Agente II': { sett: 3, ore: 30, extra: 'Almeno un raid' }, 'Agente III': { sett: 4, ore: 0, extra: 'Proposta di un Ufficiale e colloquio' } };
    const gradi = () => $$('li h4', car).map(h => h.childNodes[0]?.textContent.trim()).filter(Boolean);
    const salvato = LS.get('gu-sp-carriera', { g: 'Recluta', s: 0, o: 0 });
    car.insertAdjacentHTML('beforebegin', `
      <div class="sp-io riquadro">
        <h3 class="r-tit">Il mio percorso <small>Inserisci i tuoi dati: ti mostro quanto manca alla prossima promozione</small></h3>
        <div class="sp-io-campi">
          <label class="campo"><span>Grado attuale</span><select id="sp-io-g">${gradi().map(g => `<option ${g === salvato.g ? 'selected' : ''}>${esc(g)}</option>`).join('')}</select></label>
          <label class="campo"><span>Settimane nel grado</span><input id="sp-io-s" type="number" min="0" max="99" value="${+salvato.s || 0}"></label>
          <label class="campo"><span>Ore di servizio (<kbd>/ore</kbd>)</span><input id="sp-io-o" type="number" min="0" max="9999" value="${+salvato.o || 0}"></label>
        </div>
        <div class="sp-io-esito" id="sp-io-esito"></div>
      </div>`);
    function calcola() {
      const g = $('#sp-io-g').value, s = Math.max(0, +$('#sp-io-s').value || 0), o = Math.max(0, +$('#sp-io-o').value || 0);
      LS.set('gu-sp-carriera', { g, s, o });
      const lista = gradi(), idx = lista.indexOf(g), pros = lista[idx + 1];
      $$('li', car).forEach((li, k) => { li.classList.toggle('sp-qui', k === idx); li.classList.toggle('sp-fatto', k < idx); });
      const r = REQ[g];
      const tot = lista.length, pct = Math.round(idx / Math.max(1, tot - 1) * 100);
      let html = `<div class="sp-io-viaggio"><span>Recluta</span><i><em style="width:${pct}%"></em><b style="left:${pct}%">${esc(g)}</b></i><span>Comandante</span></div>`;
      if (!pros) html += `<div class="sp-io-top">★ Sei al vertice della Gang Unit</div>`;
      else if (!r) html += `<div class="sp-io-req"><b>Prossimo grado: ${esc(pros)}</b><p>La promozione da qui in su è a discrezione dell'Alto Comando (<a href="#art-2-4">art. 2.4</a>).</p></div>`;
      else {
        const ps = Math.min(1, s / r.sett), po = r.ore ? Math.min(1, o / r.ore) : 1, pronto = ps >= 1 && po >= 1;
        html += `<div class="sp-io-req ${pronto ? 'pronto' : ''}"><b>Prossimo grado: ${esc(pros)}</b>
          <div class="sp-io-bar"><span>⏱ Tempo nel grado</span><i><em style="width:${ps * 100}%"></em></i><small>${s} / ${r.sett} sett.</small></div>
          ${r.ore ? `<div class="sp-io-bar"><span>🕒 Ore di servizio</span><i><em style="width:${po * 100}%"></em></i><small>${o} / ${r.ore} h</small></div>` : ''}
          <p>📋 Serve anche: ${esc(r.extra)}</p>
          <div class="sp-io-verdetto">${pronto ? '✓ Hai i requisiti minimi: chiedi la valutazione al tuo Supervisore' : `Ancora ${[ps < 1 ? `${r.sett - s} sett.` : '', po < 1 ? `${r.ore - o} ore` : ''].filter(Boolean).join(' e ')} per i requisiti minimi`}</div></div>`;
      }
      $('#sp-io-esito').innerHTML = html;
    }
    $('.sp-io').addEventListener('input', calcola); $('.sp-io').addEventListener('change', calcola);
    calcola();
  }

  /* ═════════════ 7 · DOMANDE FREQUENTI: RICERCA ═════════════ */
  const faq = $('#faq');
  if (faq) {
    faq.insertAdjacentHTML('beforebegin', `<div class="sp-faq-ctl"><label class="sp-faq-cerca"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input type="search" id="sp-faq-q" placeholder="Cerca tra le domande…" aria-label="Cerca tra le domande frequenti"></label><button type="button" class="btn piccolo" id="sp-faq-tutte">Apri tutte</button><span id="sp-faq-n"></span></div>`);
    $$('details', faq).forEach((d, k) => d.querySelector('summary')?.insertAdjacentHTML('afterbegin', `<span class="sp-faq-num">${String(k + 1).padStart(2, '0')}</span>`));
    const filtra = () => { const q = $('#sp-faq-q').value.trim().toLowerCase(); let n = 0; $$('details', faq).forEach(d => { const ok = !q || d.textContent.toLowerCase().includes(q); d.hidden = !ok; if (ok) n++; if (q && ok) d.open = true; }); $('#sp-faq-n').textContent = q ? `${n} risultat${n === 1 ? 'o' : 'i'}` : ''; };
    $('#sp-faq-q').addEventListener('input', filtra);
    $('#sp-faq-tutte').addEventListener('click', e => { const tutte = $$('details', faq).filter(d => !d.hidden), apri = tutte.some(d => !d.open); tutte.forEach(d => { d.open = apri; }); e.currentTarget.textContent = apri ? 'Chiudi tutte' : 'Apri tutte'; });
  }
})();
